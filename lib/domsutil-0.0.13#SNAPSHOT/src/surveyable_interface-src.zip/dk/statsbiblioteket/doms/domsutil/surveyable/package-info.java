@javax.xml.bind.annotation.XmlSchema(namespace = "http://surveyable.domsutil.doms.statsbiblioteket.dk/")
package dk.statsbiblioteket.doms.domsutil.surveyable;
